# with-create-react-app

## 0.1.85

### Patch Changes

- Updated dependencies [7ab6e50]
- Updated dependencies [515498f]
  - @rainbow-me/rainbowkit@2.0.6

## 0.1.84

### Patch Changes

- Updated dependencies [81ba812]
- Updated dependencies [fc4d7e1]
- Updated dependencies [1a0f209]
- Updated dependencies [b11118f]
- Updated dependencies [4dd1e45]
- Updated dependencies [ec41346]
  - @rainbow-me/rainbowkit@2.0.5

## 0.1.83

### Patch Changes

- Updated dependencies [77dcec3]
- Updated dependencies [6c240ba]
- Updated dependencies [34419b5]
- Updated dependencies [5c60239]
  - @rainbow-me/rainbowkit@2.0.4

## 0.1.82

### Patch Changes

- c837995: Updated the following packages:
  - wagmi to `^2.5.11`
  - viem to `^2.8.12`
  - @tanstack/react-query to `^5.28.4`
  - typescript to `5.4.2`
- Updated dependencies [b80e8fa]
- Updated dependencies [985b80b]
- Updated dependencies [b25db9a]
  - @rainbow-me/rainbowkit@2.0.3

## 0.1.81

### Patch Changes

- Updated dependencies [524d7a0]
- Updated dependencies [2f637e4]
- Updated dependencies [c021746]
- Updated dependencies [df572f1]
  - @rainbow-me/rainbowkit@2.0.2

## 0.1.80

### Patch Changes

- d623428: Updated the following packages:
  - wagmi to `^2.5.7`
  - viem to `^2.7.12`
  - @tanstack/react-query to `^5.22.2`
- Updated dependencies [5149dbd]
- Updated dependencies [1e7d3f4]
- Updated dependencies [c16541a]
- Updated dependencies [dbca966]
- Updated dependencies [f69c0e1]
- Updated dependencies [bb56562]
- Updated dependencies [1a08977]
  - @rainbow-me/rainbowkit@2.0.1

## 0.1.79

### Patch Changes

- Updated dependencies [aa0269e]
  - @rainbow-me/rainbowkit@2.0.0

## 0.1.78

### Patch Changes

- Updated dependencies [33a8266]
  - @rainbow-me/rainbowkit@1.3.6

## 0.1.77

### Patch Changes

- Updated dependencies [2b0c7b3]
  - @rainbow-me/rainbowkit@1.3.5

## 0.1.76

### Patch Changes

- Updated dependencies [c0a644a]
- Updated dependencies [41616b9]
- Updated dependencies [cf4955f]
- Updated dependencies [e5f5f03]
- Updated dependencies [c0bd68e]
- Updated dependencies [a79609b]
  - @rainbow-me/rainbowkit@1.3.4

## 0.1.75

### Patch Changes

- Updated dependencies [24b5a88]
- Updated dependencies [7565fb2]
- Updated dependencies [5a184e9]
  - @rainbow-me/rainbowkit@1.3.3

## 0.1.74

### Patch Changes

- Updated dependencies [7ba94f48]
  - @rainbow-me/rainbowkit@1.3.2

## 0.1.73

### Patch Changes

- Updated dependencies [3feab0e6]
- Updated dependencies [c9a8e469]
- Updated dependencies [dba51779]
  - @rainbow-me/rainbowkit@1.3.1

## 0.1.72

### Patch Changes

- Updated dependencies [9ce75a65]
  - @rainbow-me/rainbowkit@1.3.0

## 0.1.71

### Patch Changes

- Updated dependencies [74ead9df]
- Updated dependencies [94dce820]
- Updated dependencies [39d81e93]
  - @rainbow-me/rainbowkit@1.2.1

## 0.1.70

### Patch Changes

- Updated dependencies [ef64a229]
  - @rainbow-me/rainbowkit@1.2.0

## 0.1.69

### Patch Changes

- Updated dependencies [9f68c300]
- Updated dependencies [3f595c12]
- Updated dependencies [e2075b31]
  - @rainbow-me/rainbowkit@1.1.4

## 0.1.68

### Patch Changes

- Updated dependencies [02e796c0]
- Updated dependencies [efb8566e]
- Updated dependencies [4b7a44c8]
- Updated dependencies [2c8abbb2]
- Updated dependencies [e41103fb]
- Updated dependencies [b0022aea]
  - @rainbow-me/rainbowkit@1.1.3

## 0.1.67

### Patch Changes

- Updated dependencies [6cbd9a57]
- Updated dependencies [7d978605]
- Updated dependencies [b2b69dcd]
  - @rainbow-me/rainbowkit@1.1.2

## 0.1.66

### Patch Changes

- Updated dependencies [b60e335c]
  - @rainbow-me/rainbowkit@1.1.1

## 0.1.65

### Patch Changes

- Updated dependencies [b37f5d68]
  - @rainbow-me/rainbowkit@1.1.0

## 0.1.64

### Patch Changes

- Updated dependencies [5b8d8219]
- Updated dependencies [fb9405a4]
- Updated dependencies [7643e706]
- Updated dependencies [252f02e8]
  - @rainbow-me/rainbowkit@1.0.12

## 0.1.63

### Patch Changes

- Updated dependencies [118dfe11]
  - @rainbow-me/rainbowkit@1.0.11

## 0.1.62

### Patch Changes

- Updated dependencies [a129cb04]
  - @rainbow-me/rainbowkit@1.0.10

## 0.1.61

### Patch Changes

- Updated dependencies [42a0c3e5]
- Updated dependencies [67933ed5]
- Updated dependencies [e7ae2571]
- Updated dependencies [c434ca7a]
- Updated dependencies [ad1f860e]
- Updated dependencies [60968a5f]
- Updated dependencies [7b31af24]
  - @rainbow-me/rainbowkit@1.0.9

## 0.1.60

### Patch Changes

- Updated dependencies [eb319f3]
  - @rainbow-me/rainbowkit@1.0.8

## 0.1.59

### Patch Changes

- Updated dependencies [f1e98e84]
- Updated dependencies [d303a3b9]
  - @rainbow-me/rainbowkit@1.0.7

## 0.1.58

### Patch Changes

- Updated dependencies [dc3cd10b]
- Updated dependencies [c251d55d]
- Updated dependencies [d5b3bd19]
- Updated dependencies [66e84239]
- Updated dependencies [1b4f142e]
- Updated dependencies [e089ab98]
  - @rainbow-me/rainbowkit@1.0.6

## 0.1.57

### Patch Changes

- Updated dependencies [08e3f4c]
- Updated dependencies [cb3614e]
- Updated dependencies [53d96bc]
- Updated dependencies [bfab830]
  - @rainbow-me/rainbowkit@1.0.5

## 0.1.56

### Patch Changes

- Updated dependencies [6d361b4]
  - @rainbow-me/rainbowkit@1.0.4

## 0.1.55

### Patch Changes

- Updated dependencies [d00c777]
  - @rainbow-me/rainbowkit@1.0.3

## 0.1.54

### Patch Changes

- Updated dependencies [e2b1072]
- Updated dependencies [e2b1072]
  - @rainbow-me/rainbowkit@1.0.2

## 0.1.53

### Patch Changes

- Updated dependencies [9432a2f]
- Updated dependencies [b2c66ff]
- Updated dependencies [bcb3d18]
  - @rainbow-me/rainbowkit@1.0.1

## 0.1.52

### Patch Changes

- Updated dependencies [93b58d0]
  - @rainbow-me/rainbowkit@1.0.0

## 0.1.51

### Patch Changes

- Updated dependencies [865175f]
  - @rainbow-me/rainbowkit@0.12.14

## 0.1.50

### Patch Changes

- Updated dependencies [0f8e87e]
- Updated dependencies [6eab54d]
  - @rainbow-me/rainbowkit@0.12.13

## 0.1.49

### Patch Changes

- Updated dependencies [ab051b9]
  - @rainbow-me/rainbowkit@0.12.12

## 0.1.48

### Patch Changes

- Updated dependencies [0469e00]
  - @rainbow-me/rainbowkit@0.12.11

## 0.1.47

### Patch Changes

- Updated dependencies [ecaa85f]
  - @rainbow-me/rainbowkit@0.12.10

## 0.1.46

### Patch Changes

- Updated dependencies [361bb39]
- Updated dependencies [82376f0]
- Updated dependencies [7c9e580]
- Updated dependencies [0127559]
  - @rainbow-me/rainbowkit@0.12.9

## 0.1.45

### Patch Changes

- Updated dependencies [aef9643]
  - @rainbow-me/rainbowkit@0.12.8

## 0.1.44

### Patch Changes

- Updated dependencies [4ef5c51]
  - @rainbow-me/rainbowkit@0.12.7

## 0.1.43

### Patch Changes

- Updated dependencies [d35809e]
  - @rainbow-me/rainbowkit@0.12.6

## 0.1.42

### Patch Changes

- Updated dependencies [2b4ede4]
- Updated dependencies [6a01368]
- Updated dependencies [936b523]
- Updated dependencies [7f669bd]
  - @rainbow-me/rainbowkit@0.12.5

## 0.1.41

### Patch Changes

- Updated dependencies [9b93f56]
  - @rainbow-me/rainbowkit@0.12.4

## 0.1.40

### Patch Changes

- Updated dependencies [e7f1bec]
- Updated dependencies [fe4f356]
  - @rainbow-me/rainbowkit@0.12.3

## 0.1.39

### Patch Changes

- Updated dependencies [2a1d230]
- Updated dependencies [429a3c7]
  - @rainbow-me/rainbowkit@0.12.2

## 0.1.38

### Patch Changes

- Updated dependencies [3399df5]
- Updated dependencies [8f01a12]
  - @rainbow-me/rainbowkit@0.12.1

## 0.1.37

### Patch Changes

- Updated dependencies [9838acf]
  - @rainbow-me/rainbowkit@0.12.0

## 0.1.36

### Patch Changes

- Updated dependencies [924ae82]
- Updated dependencies [5e233ea]
  - @rainbow-me/rainbowkit@0.11.1

## 0.1.35

### Patch Changes

- Updated dependencies [1876ba0]
  - @rainbow-me/rainbowkit@0.11.0

## 0.1.34

### Patch Changes

- Updated dependencies [355402b]
  - @rainbow-me/rainbowkit@0.10.0

## 0.1.33

### Patch Changes

- Updated dependencies [49f0ec9]
  - @rainbow-me/rainbowkit@0.9.0

## 0.1.32

### Patch Changes

- Updated dependencies [a1d6776]
  - @rainbow-me/rainbowkit@0.8.1

## 0.1.31

### Patch Changes

- Updated dependencies [6b37050]
  - @rainbow-me/rainbowkit@0.8.0

## 0.1.30

### Patch Changes

- Updated dependencies [e36da59]
- Updated dependencies [0ff4210]
  - @rainbow-me/rainbowkit@0.7.4

## 0.1.29

### Patch Changes

- Updated dependencies [5a65178]
  - @rainbow-me/rainbowkit@0.7.3

## 0.1.28

### Patch Changes

- Updated dependencies [1de8203]
  - @rainbow-me/rainbowkit@0.7.2

## 0.1.27

### Patch Changes

- Updated dependencies [6b6a73b]
- Updated dependencies [5ddc813]
  - @rainbow-me/rainbowkit@0.7.1

## 0.1.26

### Patch Changes

- Updated dependencies [2e6bb8f]
- Updated dependencies [2e6bb8f]
  - @rainbow-me/rainbowkit@0.7.0

## 0.1.25

### Patch Changes

- Updated dependencies [ecd7209]
- Updated dependencies [248a1cb]
  - @rainbow-me/rainbowkit@0.6.2

## 0.1.24

### Patch Changes

- Updated dependencies [85eb3bd]
- Updated dependencies [fbf9d82]
  - @rainbow-me/rainbowkit@0.6.1

## 0.1.23

### Patch Changes

- Updated dependencies [c944ddc]
- Updated dependencies [c944ddc]
- Updated dependencies [c944ddc]
- Updated dependencies [c944ddc]
- Updated dependencies [c944ddc]
  - @rainbow-me/rainbowkit@0.6.0

## 0.1.22

### Patch Changes

- Updated dependencies [52e2ad6]
  - @rainbow-me/rainbowkit@0.5.3

## 0.1.21

### Patch Changes

- Updated dependencies [12912b3]
- Updated dependencies [fcfc13d]
- Updated dependencies [3f9013f]
  - @rainbow-me/rainbowkit@0.5.2

## 0.1.20

### Patch Changes

- Updated dependencies [8060ccd]
- Updated dependencies [4dfe834]
- Updated dependencies [8060ccd]
  - @rainbow-me/rainbowkit@0.5.1

## 0.1.19

### Patch Changes

- Updated dependencies [737a1d6]
- Updated dependencies [488c5a1]
  - @rainbow-me/rainbowkit@0.5.0

## 0.1.18

### Patch Changes

- Updated dependencies [4333995]
  - @rainbow-me/rainbowkit@0.4.8

## 0.1.17

### Patch Changes

- Updated dependencies [1a4f2f7]
  - @rainbow-me/rainbowkit@0.4.7

## 0.1.16

### Patch Changes

- Updated dependencies [aae3163]
- Updated dependencies [948c036]
  - @rainbow-me/rainbowkit@0.4.6

## 0.1.15

### Patch Changes

- Updated dependencies [8dd5a74]
  - @rainbow-me/rainbowkit@0.4.5

## 0.1.14

### Patch Changes

- Updated dependencies [fd08aa1]
  - @rainbow-me/rainbowkit@0.4.4

## 0.1.13

### Patch Changes

- Updated dependencies [4857e75]
- Updated dependencies [c6a1033]
- Updated dependencies [396308f]
  - @rainbow-me/rainbowkit@0.4.3

## 0.1.12

### Patch Changes

- Updated dependencies [0213b52]
  - @rainbow-me/rainbowkit@0.4.2

## 0.1.11

### Patch Changes

- Updated dependencies [3637bbb]
- Updated dependencies [3637bbb]
  - @rainbow-me/rainbowkit@0.4.1

## 0.1.10

### Patch Changes

- Updated dependencies [08d189b]
  - @rainbow-me/rainbowkit@0.4.0

## 0.1.9

### Patch Changes

- Updated dependencies [b2b46ef]
  - @rainbow-me/rainbowkit@0.3.7

## 0.1.8

### Patch Changes

- Updated dependencies [d905271]
  - @rainbow-me/rainbowkit@0.3.6

## 0.1.7

### Patch Changes

- Updated dependencies [40d838e]
- Updated dependencies [1ab9c07]
- Updated dependencies [1a7d50c]
  - @rainbow-me/rainbowkit@0.3.5

## 0.1.6

### Patch Changes

- Updated dependencies [ac63f9a]
  - @rainbow-me/rainbowkit@0.3.4

## 0.1.5

### Patch Changes

- Updated dependencies [ee81177]
  - @rainbow-me/rainbowkit@0.3.3

## 0.1.4

### Patch Changes

- Updated dependencies [33a2dd7]
  - @rainbow-me/rainbowkit@0.3.2

## 0.1.3

### Patch Changes

- Updated dependencies [9d431fb]
- Updated dependencies [11ed088]
  - @rainbow-me/rainbowkit@0.3.1

## 0.1.2

### Patch Changes

- Updated dependencies [233a6d7]
  - @rainbow-me/rainbowkit@0.3.0

## 0.1.1

### Patch Changes

- Updated dependencies [ce473cd]
  - @rainbow-me/rainbowkit@0.2.5
